-- Create user
create user quicker identified by quicker;

-- Create sequence 
create sequence quicker.SEQ_FOLDER
minvalue 1
maxvalue 100000000
start with 1
increment by 1
nocache;

-- Create sequence 
create sequence quicker.SEQ_DIAGRAM
minvalue 1
maxvalue 100000000
start with 1
increment by 1
nocache;

-- Create table
create table quicker.FOLDER
(
  ID     NUMBER not null,
  NAME   VARCHAR2(100) not null,
  PARENT NUMBER
);
-- Add comments to the columns 
comment on column quicker.FOLDER.ID
  is 'Folder Id';
comment on column quicker.FOLDER.NAME
  is 'Folder Name';
comment on column quicker.FOLDER.PARENT
  is 'Parent Folder';
-- Create/Recreate primary, unique and foreign key constraints 
alter table quicker.FOLDER
  add constraint PK_FOLDER_ID primary key (ID)
  using index ;
alter table quicker.FOLDER
  add constraint UK_FOLDER unique (NAME, PARENT)
  using index ;
-- Grant/Revoke object privileges 
grant select, insert, delete on quicker.FOLDER to PUBLIC;

-- Create table
create table quicker.DIAGRAM
(
  ID         NUMBER not null,
  NAME       VARCHAR2(100) not null,
  USERID     VARCHAR2(100),
  FOLDER     NUMBER not null,
  CREATEDATE DATE default sysdate not null,
  DATA       CLOB
);
-- Add comments to the columns 
comment on column quicker.DIAGRAM.ID
  is 'Diagram id';
comment on column quicker.DIAGRAM.NAME
  is 'Name of the diagram';
comment on column quicker.DIAGRAM.USERID
  is 'OS user name of creater';
comment on column quicker.DIAGRAM.FOLDER
  is 'Folder the diagram is stored in';
comment on column quicker.DIAGRAM.CREATEDATE
  is 'Creation time';
comment on column quicker.DIAGRAM.DATA
  is 'Diagram data';
-- Create/Recreate primary, unique and foreign key constraints 
alter table quicker.DIAGRAM
  add constraint PK_DIAGRAM_ID primary key (ID)
  using index ;
alter table quicker.DIAGRAM
  add constraint UK_DIAGRAM_FOLDER unique (NAME, FOLDER)
  using index ;
alter table quicker.DIAGRAM
  add constraint FK_DIAGRAM_FOLDER foreign key (FOLDER)
  references FOLDER (ID);
-- Grant/Revoke object privileges 
grant select, insert, delete on quicker.DIAGRAM to PUBLIC;

-- Root folder
insert into QUICKER.FOLDER (ID, NAME, PARENT)
values (0, '/', null);
commit;