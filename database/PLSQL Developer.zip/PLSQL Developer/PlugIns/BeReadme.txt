Browser Extender Plug-In, version 2.0
Developed by Joachim Rupik
email: jrupik@awrsp.gov.pl


Browser Extender Plug-In is an extension for PL/SQL Developer that allows you to add menu items to browser popup menu.
Unfortunately this release does not contain any documentation, however I have provided some predefined 
Browser Extender Commands. This Plug-in should be installed into PL/SQL Developer version 4 and above.

Installation

To install the Browser Extender Plug-In, simply unpack be.zip archive file to any location on your
computer preserving directory structure and run the supplied setup.exe. This will copy the Plug-In DLL (be.dll)
and other files into PL/SQL Developer's Plugin directory.


If you like my freeware, you could send me a postcard showing the area you live in. Just drop me a line about my 
Plug-In. Mail it to:

Joachim Rupik
ul. Pulawska 266/74
02-769 Warsaw, Poland

Do not use an envelope because my son collects used postcards.
