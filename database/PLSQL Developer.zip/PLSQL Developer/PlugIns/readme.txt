Shortcuts PL/SQL Developer Plug-In
----------------------------------

Just copy shortcuts.dll and shortcuts.txt to PlugIns folder & enjoy...


tiger@softhome.net

