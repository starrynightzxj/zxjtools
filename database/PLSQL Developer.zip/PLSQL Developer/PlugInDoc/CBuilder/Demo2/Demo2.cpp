// PL/SQL Developer Plug-In demo
// Copyright 1999 Allround Automations
// support@allroundautomations.nl
// http://www.allroundautomations.nl

// This demo shows a basic use of all available functions

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Demo2Unit.h"
//---------------------------------------------------------------------------
USEFORM("Demo2Unit.cpp", DemoForm);
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
  return 1;
}
//---------------------------------------------------------------------------

