PL/SQL Developer Plug-In Interface documentation
------------------------------------------------

Complete documentation is available in the plugindoc.pdf document

Demo's are included. The CBuilder directory contains the demo's in
Borland C++Builder format (compatible with version 3 and higher).
The Delphi directory contains the same demo's in Delphi (2 and higher)
format.

Demo1: Shows an elementary interface
Demo2: Shows a basic use of all available functions
Wrap:  Shows the use of some basic functions in a practical plug-In that
       implements a wrap function. The selected object in the Browser will
       be saved as a text file and "wrapped"


Allround Automations
PO Box 40014
7504 RA  Enschede
The Netherlands

email support@allroundautomations.com
http://www.allroundautomations.com/plsqldev.html
