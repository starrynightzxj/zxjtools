-- Initialize OFS dir
begin
  ofs.init_root;
  commit;
end;
/

