
------------------- getallcode.sql -------------------------
set termout off
set heading off
set feedback off
set linesize 50
spool xtmpx.sql
select '@getcode ' || object_name
from user_objects
where object_type in ( 'PROCEDURE', 'FUNCTION', 'PACKAGE' )
AND OBJECT_NAME NOT IN ('PKG_CIRC_TP_REPORT', 'PKG_FN_FEE_PROPORTION')
/
spool off
spool getallcode_INSTALL
select '@' || object_name
from user_objects
where object_type in ( 'PROCEDURE', 'FUNCTION', 'PACKAGE' )
AND OBJECT_NAME NOT IN ('PKG_CIRC_TP_REPORT', 'PKG_FN_FEE_PROPORTION')
/
----------------------------������Ч����-----------------------------

prompt 
select 'alter '||object_type||' '|| object_name||' compile;'
  from user_objects
 where object_type in ('FUNCTION','JAVA SOURCE','JAVA CLASS','PROCEDURE','PACKAGE','TRIGGER')
 AND OBJECT_NAME NOT IN ('PKG_CIRC_TP_REPORT', 'PKG_FN_FEE_PROPORTION');

prompt
select 'alter package '||object_name||' compile body;'
  from user_objects
 where object_type = 'PACKAGE BODY'
 AND OBJECT_NAME NOT IN ('PKG_CIRC_TP_REPORT', 'PKG_FN_FEE_PROPORTION');
----------------------------������Ч����-----------------------------

/
spool off
set heading on
set feedback on
set linesize 130
set termout on
@xtmpx.sql
----------------------------------------------